#!/bin/bash

python3 interactive.py
