#!/bin/bash
echo please insert save name of your output video
read savename
ffmpeg -framerate 10 -i image_%d.ppm -vcodec mpeg4 -r 5 -b:v 8000k $savename.mp4
rm *.ppm
open -a "quicktime player" $savename.mp4

