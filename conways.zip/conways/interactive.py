import matplotlib.pyplot as plt
import matplotlib.image as image
import numpy as np


file = "image_0.ppm"
pic = image.imread(file)
picopy = np.copy(pic)

coords = []


def onclick(event):
    if event.button == 1:
        picopy[int(event.ydata)][int(event.xdata)][0] = 255
        picopy[int(event.ydata)+1][int(event.xdata)][0] = 255
        picopy[int(event.ydata)][int(event.xdata)+1][0] = 255
        picopy[int(event.ydata)-1][int(event.xdata)][0] = 255
        picopy[int(event.ydata)][int(event.xdata)-1][0] = 255
        picopy[int(event.ydata)+1][int(event.xdata)+1][0] = 255
        picopy[int(event.ydata)-1][int(event.xdata)-1][0] = 255
        picopy[int(event.ydata)+1][int(event.xdata)-1][0] = 255
        picopy[int(event.ydata)-1][int(event.xdata)+1][0] = 255
        coords.append(int(event.ydata))
        coords.append(int(event.xdata))

    plt.clf()
    plt.imshow(picopy)
    plt.ylim(0, 250)
    plt.xlim(0, 250)
    plt.xticks([])
    plt.yticks([])
    plt.title("Click on the squares to start them as alive")
    plt.figtext(0.5, 0.01, "close this window to submit your initial conditions", ha="center", fontsize=18, bbox={"facecolor":"orange", "alpha":0.5, "pad":5})
    plt.draw()






fig, ax = plt.subplots()
plt.imshow(picopy)
fig.canvas.mpl_connect('button_press_event', onclick)
plt.ylim(0, 250)
plt.xlim(0, 250)
plt.xticks([])
plt.yticks([])
plt.title("Click on the squares to start them as alive")
plt.show()
plt.figtext(0.5, 0.01, "close this window to submit your initial conditions", ha="center", fontsize=18, bbox={"facecolor":"orange", "alpha":0.5, "pad":5})



def outfile(ls):
    text_file = open("coords.txt", "w")
    count = 0
    for i in ls:
        count += 1
        text_file.write(f"{i} ")
        if count % 2 == 0:
            text_file.write("\n")
    text_file.close()


outfile(coords)













