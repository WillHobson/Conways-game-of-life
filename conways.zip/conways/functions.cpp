#include "iostream"
#include <fstream>
#include <cstdlib>

const int W = 250;
const int H = 250;


void print_array(int** array, int h, int w);
int status(int x, int y, int **arr);
int decsion(int res, int current);


void print_array(int** array, int h, int w){
    for(int i = 0; i<h; i++) {
        std::cout<<"\n";
        for (int j = 0; j < w; j++) {
            std::cout << array[i][j] << ", ";
        }}
    std::cout<<"\n";
}

int status(int x, int y, int **arr){
    int alive = 0;
    //check left
    if (x>0 && (arr[y][x-1] == 1)){ alive += 1;}

    //check right
    if (x < W &&(arr[y][x+1] == 1)){alive+=1;}

    //check top
    if (y>0 && arr[y-1][x]==1){alive+=1;}

    //check bottom
    if (y<H-1 && arr[y+1][x]==1){alive+=1;}

    //check top right
    if(x<W && y>0 && arr[y-1][x+1] ==1){alive+=1;}

    //check bottom right
    if (x<W && y<H-1 && arr[y+1][x+1]==1){alive+=1;}

    //check bottom left
    if(x>0 && y<H-1 && arr[y+1][x-1]==1){alive+=1;}

    //check top left
    if(x>0 && y>0 && arr[y-1][x-1]==1){alive+=1;}

    return alive;
}

int decsion(int res, int current){
    int newv;
    if (current == 1){
        if (res <2){newv = 0;}
        if (res==2 || res==3){newv = 1;}
        if (res >3){newv = 0;}
    }

    else {
        if (current == 0 && (res == 3)) { newv = 1; }
        else (newv = 0);
    }

    return newv;
}



using namespace std;


void pic(string path, int height, int width, int** arr) {
    ofstream image;
    image.open(path);
    if (image.is_open()){
        //place header info
        image << "P3" << endl;
        image << "250 250"<< endl;
        image << "255" <<endl;

        for(int y=0; y<250; y++){
            for (int x = 0; x<250; x++){
                if(arr[y][x] == 1){image<<255<<" " << 0<< " "<<0<<endl;}
                else {image<<0<<" " << 0<< " "<<0<<endl;}
            }
        }
    }
    image.close();
}


void render()
{
    std::system("./macos_render.sh");
}

void python(){
    std::system("./macos_python.sh");
}

int setup(int **array) {


    int n = 0; //n is the number of the integers in the file ==> 12
    int*arr = new int[10000];

    ifstream File;

    File.open("coords.txt");

    while(!File.eof())
    {
        File >> arr[n];
        n++;
    }

    File.close();


    for (int i = 0; i<n-1; i+=2)
    {
        array[arr[i]*-1 + 250][(arr[i+1])]=1;
        array[arr[i]*-1 + 250][(arr[i+1]+1)]=1;
        array[arr[i]*-1 + 250][(arr[i+1]-1)]=1;
        array[arr[i]*-1 + 250 + 1][(arr[i+1])]=1;
        array[arr[i]*-1 + 250-1][(arr[i+1])]=1;
        array[arr[i]*-1 + 250 + 1][(arr[i+1])+1]=1;
        array[arr[i]*-1 + 250 - 1][(arr[i+1])-1]=1;
        array[arr[i]*-1 + 250 -1 ][(arr[i+1])+1]=1;
        array[arr[i]*-1 + 250+1][(arr[i+1])-1]=1;

    }
    pic("/Users/willhob/ClionProjects/untitled/image_0.ppm", H, W,array);
    delete [] arr;
    return 0;
}
