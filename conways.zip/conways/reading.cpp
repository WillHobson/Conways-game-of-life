//
// Created by Will Hobson on 20/08/2022.
//
#include <fstream>
#include<iostream>
//#include "functions.cpp"
using namespace std;
int setup(int **array) {


        int n = 0; //n is the number of the integers in the file ==> 12
        int*arr = new int[1000];

        ifstream File;
        File.open("coords.txt");
        while(!File.eof())
        {
            File >> arr[n];
            n++;
        }
        cout<<"number of lines we accepting"<< n/2 <<endl;
        File.close();



        for (int i = 0; i<n/2; i+=2)
        {
            array[arr[i]][arr[i+1]]=1;
    }

        pic("/Users/willhob/ClionProjects/untitled/image_0.ppm", H, W,array);
        delete [] arr;
        return 0;
    }


