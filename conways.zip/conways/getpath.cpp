//
// Created by Will Hobson on 16/08/2022.
//
#include <mach-o/dyld.h>
#include <string>

std::string getpath () {
    char path[250];
    uint32_t size = sizeof(path);
    _NSGetExecutablePath(path, &size);
    return path;
}