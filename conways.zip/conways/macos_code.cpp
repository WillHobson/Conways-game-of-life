//
// Created by Will Hobson on 16/08/2022.
//
#include "iostream"
#include "functions.cpp"
#include "getpath.cpp"


using namespace std;


int main(){
    int count = 0; //variable to keep count of generations.
    //srand(time(0));
    int** a2d = new int*[W*H];//allocated memory


    for (int i=0; i<W; i++){         //setting up a2d array
        a2d[i] = new int[H];
    }


//filling up initial array
    for (int i=0; i<H; i++) {
        for (int j = 0; j < W; j++) {
            a2d[i][j] = 0;}}
    //need to output an images of blank array here
    string path_original = "/Users/willhob/ClionProjects/untitled/image_0.ppm";
    pic(path_original, H, W, a2d);
    //get original setup coords from python
    python();
    setup(a2d);

    int lifetime;
    cout<<"HOW MANY GENERATIONS WOULD YOU LIKE TO RUN YOUR SIMULATION FOR?  ";
    cin>>lifetime;
    cout<<"PLEASE WAIT";



    while(count<lifetime) {
        int** b2d = new int*[W*H];
        for (int i=0; i<W; i++){            //setting up b2d array
            b2d[i] = new int[H];
        }
        for (int i=0; i<H; i++) {
            for (int j = 0; j < W; j++) {
                b2d[i][j] = 0;}}
        //string path = getpath()  + "image_" + to_string(count) + ".ppm";
        //std::cout<<"path = "<< path;
        string path = "/Users/willhob/ClionProjects/untitled/image_"+ std::to_string(count+1) + ".ppm";

        pic(path, H, W, a2d);

        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                int res = status(i, j, a2d);
                int des = decsion(res, a2d[j][i]);
                b2d[j][i] = des;
            }
        }



        for (int i=0; i<H; i++){
            std::swap(a2d[i], b2d[i]);
        }
        count++;


        //delete b2d
        for (int i = 0; i < W; i++) {
            delete[] b2d[i];
        }
        delete[] b2d;
    }
    render();
}
